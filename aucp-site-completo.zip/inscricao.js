(() => {
  const STEPS = [
    { id: 1, title: 'Candidato' },
    { id: 2, title: 'Académico' },
    { id: 3, title: 'Económico' },
    { id: 4, title: 'Cursos' },
    { id: 5, title: 'Motivação' },
    { id: 6, title: 'Declaração' },
  ];

  const CURSOS = [
    'Marketing','Comunicação Pública e Publicidade','Técnico Logístico',
    'Auxiliar de saúde','Multimédia','Produção Agropecuária',
    'Bombeiro','Gestão e Programação de Sistemas Informáticos','Gestão Administrativa',
    'Cozinha e Restauração','Instalações Elétricas','Soldadura',
    'Desenho e Design Industrial','Enologia e Enoturismo',
  ];
  const CUSTEAR = ['Visto','Passagem','Hospedagem (1-2 meses)','Alimentação inicial'];

  let currentStep = 1;
  const form = document.getElementById('form');
  const stepsEl = document.getElementById('steps');
  const progress = document.getElementById('progress');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const submitBtn = document.getElementById('submitBtn');
  const stepIndicator = document.getElementById('stepIndicator');
  const toast = document.getElementById('toast');

  // Year
  document.getElementById('year').textContent = new Date().getFullYear();

  // Build stepper
  STEPS.forEach((s) => {
    const item = document.createElement('div');
    item.className = 'step-item';
    item.dataset.step = s.id;
    item.innerHTML = `<div class="step-circle">${s.id}</div><div class="step-label">${s.title}</div>`;
    stepsEl.appendChild(item);
  });

  // Build checkbox lists
  function buildChecks(containerId, items, name) {
    const c = document.getElementById(containerId);
    items.forEach((label) => {
      const id = `${name}-${label.replace(/\W+/g,'_')}`;
      const wrap = document.createElement('label');
      wrap.className = 'check-item';
      wrap.innerHTML = `<input type="checkbox" name="${name}" value="${label}" id="${id}"/><span>${label}</span>`;
      const cb = wrap.querySelector('input');
      cb.addEventListener('change', () => wrap.classList.toggle('checked', cb.checked));
      c.appendChild(wrap);
    });
  }
  buildChecks('cursosList', CURSOS, 'cursos');
  buildChecks('custearList', CUSTEAR, 'custear');

  // Pills
  document.querySelectorAll('[data-pills]').forEach((group) => {
    const name = group.dataset.pills;
    const hidden = form.querySelector(`input[name="${name}"]`);
    group.querySelectorAll('.pill').forEach((btn) => {
      btn.addEventListener('click', () => {
        group.querySelectorAll('.pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        hidden.value = btn.dataset.value;
        // conditional fields
        if (name === 'familiaresPT') {
          document.getElementById('familiaresQuemWrap').classList.toggle('hidden', btn.dataset.value !== 'Sim');
        }
        if (name === 'informatica') {
          document.getElementById('informaticaDescWrap').classList.toggle('hidden', btn.dataset.value !== 'Sim');
        }
      });
    });
  });

  function showToast(msg, type = 'error') {
    toast.textContent = msg;
    toast.className = `toast show ${type}`;
    setTimeout(() => toast.classList.remove('show'), 3000);
  }

  function updateUI() {
    document.querySelectorAll('.step').forEach(s => {
      s.classList.toggle('hidden', Number(s.dataset.step) !== currentStep);
    });
    document.querySelectorAll('.step-item').forEach(s => {
      const n = Number(s.dataset.step);
      s.classList.toggle('active', n === currentStep);
      s.classList.toggle('done', n < currentStep);
    });
    progress.style.width = `${(currentStep / STEPS.length) * 100}%`;
    stepIndicator.textContent = `Passo ${currentStep} de ${STEPS.length}`;
    prevBtn.disabled = currentStep === 1;
    nextBtn.classList.toggle('hidden', currentStep === STEPS.length);
    submitBtn.classList.toggle('hidden', currentStep !== STEPS.length);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function val(name) {
    const el = form.querySelector(`[name="${name}"]`);
    return el ? el.value.trim() : '';
  }

  function validateStep() {
    if (currentStep === 1) {
      if (!val('nomeCompleto')) return 'Indica o nome completo.';
      if (!val('dataNascDia') || !val('dataNascMes') || !val('dataNascAno')) return 'Indica a data de nascimento.';
      if (!val('sexo')) return 'Indica o sexo.';
      if (!val('nacionalidade')) return 'Indica a nacionalidade.';
      if (!val('passaporte')) return 'Indica o nº de passaporte.';
      if (!val('telefone')) return 'Indica o telefone.';
      if (!/^\S+@\S+\.\S+$/.test(val('email'))) return 'Email inválido.';
      if (!val('endereco')) return 'Indica o endereço.';
      if (!val('nomePai') || !val('nomeMae')) return 'Indica os nomes dos pais.';
      if (!val('familiaresPT')) return 'Indica se possui familiares em Portugal.';
    }
    if (currentStep === 2) {
      if (!val('ultimaClasse')) return 'Indica a última classe concluída.';
      if (!val('escola')) return 'Indica a escola.';
      if (!val('anoConclusao')) return 'Indica o ano de conclusão.';
      if (!val('ingles')) return 'Seleciona o nível de inglês.';
      if (!val('informatica')) return 'Indica conhecimento de informática.';
    }
    if (currentStep === 3) {
      if (!val('rendimento')) return 'Seleciona o rendimento mensal.';
    }
    if (currentStep === 4) {
      const cursos = form.querySelectorAll('input[name="cursos"]:checked');
      if (cursos.length === 0) return 'Seleciona pelo menos um curso.';
    }
    if (currentStep === 5) {
      if (!val('motivacao')) return 'Explica a motivação.';
    }
    return null;
  }

  prevBtn.addEventListener('click', () => {
    if (currentStep > 1) { currentStep--; updateUI(); }
  });
  nextBtn.addEventListener('click', () => {
    const err = validateStep();
    if (err) return showToast(err);
    if (currentStep < STEPS.length) { currentStep++; updateUI(); }
  });

  const DESTINO_EMAIL = 'aucpconexao@gmail.com';
  const FORMSUBMIT_URL = 'https://formsubmit.co/ajax/' + DESTINO_EMAIL;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = validateStep();
    if (err) return showToast(err);
    if (!form.querySelector('[name="declaracao"]').checked) return showToast('Confirma a declaração.');
    if (!val('assinatura')) return showToast('Indica a assinatura.');
    if (!val('dataDia') || !val('dataMes') || !val('dataAno')) return showToast('Indica a data.');

    // Coletar dados (agrupando múltiplos valores)
    const data = {};
    new FormData(form).forEach((v, k) => {
      if (data[k] !== undefined) data[k] = [].concat(data[k], v);
      else data[k] = v;
    });
    // Campos auxiliares para o FormSubmit
    data._subject = `Nova candidatura AUCP — ${data.nomeCompleto || 'Candidato'}`;
    data._template = 'table';
    data._captcha = 'false';

    submitBtn.disabled = true;
    const originalLabel = submitBtn.innerHTML;
    submitBtn.innerHTML = 'A enviar...';

    try {
      const res = await fetch(FORMSUBMIT_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error('Falha no envio');
      form.classList.add('hidden');
      document.getElementById('success').classList.remove('hidden');
      showToast('Candidatura enviada com sucesso!', 'success');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      console.error(err);
      showToast('Erro ao enviar. Tenta novamente em instantes.');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalLabel;
    }
  });

  document.getElementById('resetBtn').addEventListener('click', () => {
    form.reset();
    document.querySelectorAll('.pill.active').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.check-item.checked').forEach(p => p.classList.remove('checked'));
    document.getElementById('familiaresQuemWrap').classList.add('hidden');
    document.getElementById('informaticaDescWrap').classList.add('hidden');
    document.getElementById('success').classList.add('hidden');
    form.classList.remove('hidden');
    currentStep = 1;
    updateUI();
  });

  updateUI();
})();
