// ===== Year =====
document.getElementById('year').textContent = new Date().getFullYear();

// ===== Mobile menu =====
const menuBtn = document.getElementById('menuBtn');
const navLinks = document.getElementById('navLinks');
menuBtn.addEventListener('click', () => navLinks.classList.toggle('open'));
navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navLinks.classList.remove('open')));

// ===== Marquee items =====
const marqueeItems = [
  ['🎓','Apoio à candidatura universitária'],
  ['📄','Legalização & Visto de estudo'],
  ['🏠','Procura de alojamento'],
  ['✈️','Acolhimento à chegada'],
  ['📚','Mentoria académica'],
  ['👥','Eventos culturais moçambicanos'],
  ['🤝','Apoio psicossocial'],
  ['💼','Estágios e empregabilidade'],
];
const track = document.getElementById('marqueeTrack');
const loop = [...marqueeItems, ...marqueeItems];
track.innerHTML = loop.map(([i,t]) =>
  `<div class="marquee-item"><span class="ico">${i}</span><span>${t}</span><span class="sep">◆</span></div>`
).join('');

// ===== Features =====
const features = [
  ['🎓','Acesso ao Ensino','Apoio na candidatura, equivalências e matrícula em universidades portuguesas.'],
  ['🛡️','Legalização','Orientação completa em vistos, AIMA e documentação.'],
  ['🌍','Integração Cultural','Eventos, encontros e uma comunidade que sente como casa.'],
  ['❤️','Acompanhamento','Mentoria académica, apoio psicossocial e rede de entreajuda.'],
];
document.getElementById('featuresGrid').innerHTML = features.map(([i,t,d]) =>
  `<div class="feature"><div class="icon">${i}</div><h3>${t}</h3><p>${d}</p></div>`
).join('');

// ===== Active nav on scroll =====
const sections = ['inicio','sobre','servicos','inscricao','contacto'];
const navAnchors = navLinks.querySelectorAll('a');
window.addEventListener('scroll', () => {
  const y = window.scrollY + 120;
  let cur = sections[0];
  sections.forEach(id => {
    const el = document.getElementById(id);
    if (el && el.offsetTop <= y) cur = id;
  });
  navAnchors.forEach(a => {
    const href = a.getAttribute('href');
    a.classList.toggle('active', href === '#' + cur);
  });
});
